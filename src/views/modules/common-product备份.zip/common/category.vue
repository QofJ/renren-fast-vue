<template>
  <el-tree :data="menus" :props="defaultProps" node-key="catId" ref="menuTree" @node-click="nodeclick">

  </el-tree>
</template>

<script>
export default {
  name: '',
  props: {
  },
  components: {

  },
  data() {
    return {

      menus: [],
      expandedKey: [],
      defaultProps: {
        children: 'children',
        label: 'name'
      }
    }
  },
  methods: {
    getMenus() {
      this.$http({
        url: this.$http.adornUrl('/product/category/list/tree'),
        method: 'get'
      }).then(({ data: { data } }) => {
        this.menus = data
      })
    },
    nodeclick(data, node, component) {
      console.log("子组件category的节点被点击了：", data, node, component)
      this.$emit('tree-node-click', data, node, component)
    }
  },
  created() {
    this.getMenus()
  },
  mounted() {

  },
  watch: {

  },
  computed: {

  },
  filters: {

  }
}
</script>

<style scoped></style>